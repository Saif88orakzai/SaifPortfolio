var typed = new Typed(".auto-type", { 
    strings: [". . . . . . . . ." ],
    typeSpeed: 150,
    backSpeed: 150,
    loop: true
})